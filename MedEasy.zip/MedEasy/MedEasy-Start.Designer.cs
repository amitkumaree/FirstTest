﻿namespace MedEasy
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_viewItemGrid = new System.Windows.Forms.Panel();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.dataGrid_Item = new System.Windows.Forms.DataGridView();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openingStockToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenu = new System.Windows.Forms.MenuStrip();
            this.pnl_CreateItem = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.btn_save = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.combobx_GName = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.lbl_gName = new System.Windows.Forms.Label();
            this.lbl_Name = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.lbl_ID = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pnl_stockOpeningStock = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.lbl_StockRatio = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.dateTimePicker_StockExpiry = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.dataGridView_ShowStock = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnl_viewItemGrid.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Item)).BeginInit();
            this.mainMenu.SuspendLayout();
            this.pnl_CreateItem.SuspendLayout();
            this.pnl_stockOpeningStock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ShowStock)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_viewItemGrid
            // 
            this.pnl_viewItemGrid.Controls.Add(this.textBox18);
            this.pnl_viewItemGrid.Controls.Add(this.dataGrid_Item);
            this.pnl_viewItemGrid.Location = new System.Drawing.Point(904, 27);
            this.pnl_viewItemGrid.Name = "pnl_viewItemGrid";
            this.pnl_viewItemGrid.Size = new System.Drawing.Size(287, 444);
            this.pnl_viewItemGrid.TabIndex = 2;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(3, 22);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(281, 21);
            this.textBox18.TabIndex = 1;
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // dataGrid_Item
            // 
            this.dataGrid_Item.AllowUserToOrderColumns = true;
            this.dataGrid_Item.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_Item.Location = new System.Drawing.Point(0, 56);
            this.dataGrid_Item.Name = "dataGrid_Item";
            this.dataGrid_Item.Size = new System.Drawing.Size(287, 340);
            this.dataGrid_Item.TabIndex = 0;
            this.dataGrid_Item.SelectionChanged += new System.EventHandler(this.dataGrid_Item_SelectionChanged);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.toolStripSeparator1,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.newToolStripMenuItem.Text = "New";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.openToolStripMenuItem.Text = "Open";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(100, 6);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.quitToolStripMenuItem.Text = "Quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // createToolStripMenuItem
            // 
            this.createToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itemToolStripMenuItem});
            this.createToolStripMenuItem.Name = "createToolStripMenuItem";
            this.createToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.createToolStripMenuItem.Text = "Create";
            // 
            // itemToolStripMenuItem
            // 
            this.itemToolStripMenuItem.Name = "itemToolStripMenuItem";
            this.itemToolStripMenuItem.Size = new System.Drawing.Size(98, 22);
            this.itemToolStripMenuItem.Text = "Item";
            this.itemToolStripMenuItem.Click += new System.EventHandler(this.itemToolStripMenuItem_Click);
            // 
            // stockToolStripMenuItem
            // 
            this.stockToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openingStockToolStripMenuItem});
            this.stockToolStripMenuItem.Name = "stockToolStripMenuItem";
            this.stockToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.stockToolStripMenuItem.Text = "Stock";
            // 
            // openingStockToolStripMenuItem
            // 
            this.openingStockToolStripMenuItem.Name = "openingStockToolStripMenuItem";
            this.openingStockToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.openingStockToolStripMenuItem.Text = "Opening Stock";
            this.openingStockToolStripMenuItem.Click += new System.EventHandler(this.openingStockToolStripMenuItem_Click);
            // 
            // mainMenu
            // 
            this.mainMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.createToolStripMenuItem,
            this.stockToolStripMenuItem});
            this.mainMenu.Location = new System.Drawing.Point(0, 0);
            this.mainMenu.Name = "mainMenu";
            this.mainMenu.Size = new System.Drawing.Size(1210, 24);
            this.mainMenu.TabIndex = 0;
            this.mainMenu.Text = "medEasyMenu";
            // 
            // pnl_CreateItem
            // 
            this.pnl_CreateItem.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_CreateItem.Controls.Add(this.label19);
            this.pnl_CreateItem.Controls.Add(this.textBox17);
            this.pnl_CreateItem.Controls.Add(this.btn_save);
            this.pnl_CreateItem.Controls.Add(this.btn_update);
            this.pnl_CreateItem.Controls.Add(this.btn_del);
            this.pnl_CreateItem.Controls.Add(this.label14);
            this.pnl_CreateItem.Controls.Add(this.textBox15);
            this.pnl_CreateItem.Controls.Add(this.label18);
            this.pnl_CreateItem.Controls.Add(this.textBox16);
            this.pnl_CreateItem.Controls.Add(this.label17);
            this.pnl_CreateItem.Controls.Add(this.label11);
            this.pnl_CreateItem.Controls.Add(this.textBox12);
            this.pnl_CreateItem.Controls.Add(this.textBox3);
            this.pnl_CreateItem.Controls.Add(this.label15);
            this.pnl_CreateItem.Controls.Add(this.label12);
            this.pnl_CreateItem.Controls.Add(this.textBox13);
            this.pnl_CreateItem.Controls.Add(this.textBox10);
            this.pnl_CreateItem.Controls.Add(this.label16);
            this.pnl_CreateItem.Controls.Add(this.label13);
            this.pnl_CreateItem.Controls.Add(this.textBox14);
            this.pnl_CreateItem.Controls.Add(this.textBox11);
            this.pnl_CreateItem.Controls.Add(this.comboBox4);
            this.pnl_CreateItem.Controls.Add(this.label10);
            this.pnl_CreateItem.Controls.Add(this.comboBox3);
            this.pnl_CreateItem.Controls.Add(this.label9);
            this.pnl_CreateItem.Controls.Add(this.comboBox2);
            this.pnl_CreateItem.Controls.Add(this.label8);
            this.pnl_CreateItem.Controls.Add(this.comboBox1);
            this.pnl_CreateItem.Controls.Add(this.label7);
            this.pnl_CreateItem.Controls.Add(this.combobx_GName);
            this.pnl_CreateItem.Controls.Add(this.label4);
            this.pnl_CreateItem.Controls.Add(this.textBox7);
            this.pnl_CreateItem.Controls.Add(this.label5);
            this.pnl_CreateItem.Controls.Add(this.textBox8);
            this.pnl_CreateItem.Controls.Add(this.label6);
            this.pnl_CreateItem.Controls.Add(this.textBox9);
            this.pnl_CreateItem.Controls.Add(this.label3);
            this.pnl_CreateItem.Controls.Add(this.textBox6);
            this.pnl_CreateItem.Controls.Add(this.label2);
            this.pnl_CreateItem.Controls.Add(this.textBox5);
            this.pnl_CreateItem.Controls.Add(this.label1);
            this.pnl_CreateItem.Controls.Add(this.textBox4);
            this.pnl_CreateItem.Controls.Add(this.lbl_gName);
            this.pnl_CreateItem.Controls.Add(this.lbl_Name);
            this.pnl_CreateItem.Controls.Add(this.textBox2);
            this.pnl_CreateItem.Controls.Add(this.lbl_ID);
            this.pnl_CreateItem.Controls.Add(this.textBox1);
            this.pnl_CreateItem.Location = new System.Drawing.Point(48, 29);
            this.pnl_CreateItem.Name = "pnl_CreateItem";
            this.pnl_CreateItem.Size = new System.Drawing.Size(553, 409);
            this.pnl_CreateItem.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(358, 56);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 13);
            this.label19.TabIndex = 42;
            this.label19.Text = "Power:";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(410, 53);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(80, 21);
            this.textBox17.TabIndex = 41;
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(416, 364);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(75, 23);
            this.btn_save.TabIndex = 40;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(262, 364);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 39;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(114, 364);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(75, 23);
            this.btn_del.TabIndex = 38;
            this.btn_del.Text = "Delete";
            this.btn_del.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(204, 319);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 13);
            this.label14.TabIndex = 37;
            this.label14.Text = "Remarks:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(262, 316);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(228, 21);
            this.textBox15.TabIndex = 36;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(31, 319);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 13);
            this.label18.TabIndex = 35;
            this.label18.Text = "Unit Rate:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(114, 316);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(80, 21);
            this.textBox16.TabIndex = 34;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(357, 293);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(35, 13);
            this.label17.TabIndex = 33;
            this.label17.Text = "D% 3:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(356, 267);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 32;
            this.label11.Text = "Rack:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(410, 290);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(80, 21);
            this.textBox12.TabIndex = 22;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(410, 264);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(80, 21);
            this.textBox3.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(221, 293);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 21;
            this.label15.Text = "D% 2:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(203, 267);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 13);
            this.label12.TabIndex = 30;
            this.label12.Text = "Margin %:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(262, 290);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(80, 21);
            this.textBox13.TabIndex = 20;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(262, 264);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(80, 21);
            this.textBox10.TabIndex = 29;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(73, 293);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 13);
            this.label16.TabIndex = 19;
            this.label16.Text = "D% 1:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(17, 267);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(90, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Reorder Quantity:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(114, 290);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(80, 21);
            this.textBox14.TabIndex = 18;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(114, 264);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(80, 21);
            this.textBox11.TabIndex = 27;
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(114, 237);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(376, 21);
            this.comboBox4.TabIndex = 26;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(59, 240);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 25;
            this.label10.Text = "Division:";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(114, 210);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(376, 21);
            this.comboBox3.TabIndex = 24;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(33, 213);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Manufacturer:";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(114, 183);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(376, 21);
            this.comboBox2.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(51, 186);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Schedule:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Select",
            "Alopathy",
            "Homeopathy"});
            this.comboBox1.Location = new System.Drawing.Point(114, 156);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(376, 21);
            this.comboBox1.TabIndex = 20;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(74, 159);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(34, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "Type:";
            // 
            // combobx_GName
            // 
            this.combobx_GName.FormattingEnabled = true;
            this.combobx_GName.Location = new System.Drawing.Point(114, 77);
            this.combobx_GName.Name = "combobx_GName";
            this.combobx_GName.Size = new System.Drawing.Size(376, 21);
            this.combobx_GName.TabIndex = 18;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(356, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Rate %:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(410, 130);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(80, 21);
            this.textBox7.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(203, 133);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Sales Unit:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(262, 130);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(80, 21);
            this.textBox8.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(31, 133);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Purchase Unit:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(114, 130);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(80, 21);
            this.textBox9.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(352, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "CGST %:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(410, 104);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(80, 21);
            this.textBox6.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(214, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "IGST %:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(262, 104);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(80, 21);
            this.textBox5.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Pack:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(114, 104);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(80, 21);
            this.textBox4.TabIndex = 6;
            // 
            // lbl_gName
            // 
            this.lbl_gName.AutoSize = true;
            this.lbl_gName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gName.Location = new System.Drawing.Point(28, 81);
            this.lbl_gName.Name = "lbl_gName";
            this.lbl_gName.Size = new System.Drawing.Size(78, 13);
            this.lbl_gName.TabIndex = 5;
            this.lbl_gName.Text = "Generic Name:";
            // 
            // lbl_Name
            // 
            this.lbl_Name.AutoSize = true;
            this.lbl_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Name.Location = new System.Drawing.Point(69, 55);
            this.lbl_Name.Name = "lbl_Name";
            this.lbl_Name.Size = new System.Drawing.Size(38, 13);
            this.lbl_Name.TabIndex = 3;
            this.lbl_Name.Text = "Name:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(114, 52);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(228, 21);
            this.textBox2.TabIndex = 2;
            // 
            // lbl_ID
            // 
            this.lbl_ID.AutoSize = true;
            this.lbl_ID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ID.Location = new System.Drawing.Point(87, 29);
            this.lbl_ID.Name = "lbl_ID";
            this.lbl_ID.Size = new System.Drawing.Size(21, 13);
            this.lbl_ID.TabIndex = 1;
            this.lbl_ID.Text = "ID:";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(114, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(155, 21);
            this.textBox1.TabIndex = 0;
            // 
            // pnl_stockOpeningStock
            // 
            this.pnl_stockOpeningStock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnl_stockOpeningStock.Controls.Add(this.button3);
            this.pnl_stockOpeningStock.Controls.Add(this.button2);
            this.pnl_stockOpeningStock.Controls.Add(this.label31);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox30);
            this.pnl_stockOpeningStock.Controls.Add(this.label30);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox29);
            this.pnl_stockOpeningStock.Controls.Add(this.label29);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox28);
            this.pnl_stockOpeningStock.Controls.Add(this.label28);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox27);
            this.pnl_stockOpeningStock.Controls.Add(this.label27);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox26);
            this.pnl_stockOpeningStock.Controls.Add(this.label26);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox25);
            this.pnl_stockOpeningStock.Controls.Add(this.label25);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox24);
            this.pnl_stockOpeningStock.Controls.Add(this.label24);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox23);
            this.pnl_stockOpeningStock.Controls.Add(this.lbl_StockRatio);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox22);
            this.pnl_stockOpeningStock.Controls.Add(this.dateTimePicker_StockExpiry);
            this.pnl_stockOpeningStock.Controls.Add(this.label23);
            this.pnl_stockOpeningStock.Controls.Add(this.label22);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox21);
            this.pnl_stockOpeningStock.Controls.Add(this.label21);
            this.pnl_stockOpeningStock.Controls.Add(this.label20);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox20);
            this.pnl_stockOpeningStock.Controls.Add(this.textBox19);
            this.pnl_stockOpeningStock.Controls.Add(this.dataGridView_ShowStock);
            this.pnl_stockOpeningStock.Location = new System.Drawing.Point(48, 444);
            this.pnl_stockOpeningStock.Name = "pnl_stockOpeningStock";
            this.pnl_stockOpeningStock.Size = new System.Drawing.Size(553, 409);
            this.pnl_stockOpeningStock.TabIndex = 43;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(458, 89);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 23);
            this.button3.TabIndex = 70;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(376, 89);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(76, 23);
            this.button2.TabIndex = 69;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(4, 94);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(52, 13);
            this.label31.TabIndex = 68;
            this.label31.Text = "Remarks:";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(57, 91);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(307, 21);
            this.textBox30.TabIndex = 67;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(456, 47);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(54, 13);
            this.label30.TabIndex = 66;
            this.label30.Text = "Net Total:";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(458, 62);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(80, 21);
            this.textBox29.TabIndex = 65;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(374, 47);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(34, 13);
            this.label29.TabIndex = 64;
            this.label29.Text = "MRP:";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(376, 62);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(75, 21);
            this.textBox28.TabIndex = 63;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(223, 47);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(28, 13);
            this.label28.TabIndex = 62;
            this.label28.Text = "Tax:";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(225, 62);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(49, 21);
            this.textBox27.TabIndex = 61;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(283, 47);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 13);
            this.label27.TabIndex = 60;
            this.label27.Text = "Amount:";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(285, 62);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(79, 21);
            this.textBox26.TabIndex = 59;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(156, 47);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(33, 13);
            this.label26.TabIndex = 58;
            this.label26.Text = "Rate:";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(158, 62);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(52, 21);
            this.textBox25.TabIndex = 57;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(89, 47);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 13);
            this.label25.TabIndex = 56;
            this.label25.Text = "Unit:";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(91, 62);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(49, 21);
            this.textBox24.TabIndex = 55;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(4, 47);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 13);
            this.label24.TabIndex = 54;
            this.label24.Text = "Quantity:";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(6, 62);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(76, 21);
            this.textBox23.TabIndex = 53;
            // 
            // lbl_StockRatio
            // 
            this.lbl_StockRatio.AutoSize = true;
            this.lbl_StockRatio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_StockRatio.Location = new System.Drawing.Point(456, 5);
            this.lbl_StockRatio.Name = "lbl_StockRatio";
            this.lbl_StockRatio.Size = new System.Drawing.Size(35, 13);
            this.lbl_StockRatio.TabIndex = 52;
            this.lbl_StockRatio.Text = "Ratio:";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(458, 20);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(80, 21);
            this.textBox22.TabIndex = 51;
            // 
            // dateTimePicker_StockExpiry
            // 
            this.dateTimePicker_StockExpiry.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker_StockExpiry.Location = new System.Drawing.Point(377, 20);
            this.dateTimePicker_StockExpiry.Name = "dateTimePicker_StockExpiry";
            this.dateTimePicker_StockExpiry.Size = new System.Drawing.Size(75, 21);
            this.dateTimePicker_StockExpiry.TabIndex = 50;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(375, 5);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(28, 13);
            this.label23.TabIndex = 49;
            this.label23.Text = "Exp:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(282, 5);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(38, 13);
            this.label22.TabIndex = 47;
            this.label22.Text = "Batch:";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(284, 20);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(80, 21);
            this.textBox21.TabIndex = 46;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 5);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 13);
            this.label21.TabIndex = 45;
            this.label21.Text = "ID:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(89, 5);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(38, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Name:";
            // 
            // textBox20
            // 
            this.textBox20.Enabled = false;
            this.textBox20.Location = new System.Drawing.Point(5, 20);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(77, 21);
            this.textBox20.TabIndex = 44;
            // 
            // textBox19
            // 
            this.textBox19.Enabled = false;
            this.textBox19.Location = new System.Drawing.Point(91, 20);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(183, 21);
            this.textBox19.TabIndex = 4;
            // 
            // dataGridView_ShowStock
            // 
            this.dataGridView_ShowStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_ShowStock.Location = new System.Drawing.Point(4, 131);
            this.dataGridView_ShowStock.Name = "dataGridView_ShowStock";
            this.dataGridView_ShowStock.Size = new System.Drawing.Size(545, 274);
            this.dataGridView_ShowStock.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pnl_stockOpeningStock);
            this.panel1.Controls.Add(this.pnl_CreateItem);
            this.panel1.Location = new System.Drawing.Point(0, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(898, 721);
            this.panel1.TabIndex = 3;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 741);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnl_viewItemGrid);
            this.Controls.Add(this.mainMenu);
            this.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.mainMenu;
            this.Name = "Main";
            this.Text = "Med Easy";
            this.pnl_viewItemGrid.ResumeLayout(false);
            this.pnl_viewItemGrid.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_Item)).EndInit();
            this.mainMenu.ResumeLayout(false);
            this.mainMenu.PerformLayout();
            this.pnl_CreateItem.ResumeLayout(false);
            this.pnl_CreateItem.PerformLayout();
            this.pnl_stockOpeningStock.ResumeLayout(false);
            this.pnl_stockOpeningStock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ShowStock)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnl_viewItemGrid;
        private System.Windows.Forms.DataGridView dataGrid_Item;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stockToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openingStockToolStripMenuItem;
        private System.Windows.Forms.MenuStrip mainMenu;
        private System.Windows.Forms.Panel pnl_CreateItem;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox combobx_GName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label lbl_gName;
        private System.Windows.Forms.Label lbl_Name;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label lbl_ID;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel pnl_stockOpeningStock;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label lbl_StockRatio;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.DateTimePicker dateTimePicker_StockExpiry;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.DataGridView dataGridView_ShowStock;
        private System.Windows.Forms.Panel panel1;


    }
}

